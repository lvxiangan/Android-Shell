#ifndef _SECURITY_DECRYPT_H_
#define _SECURITY_DECRYPT_H_

class Security {
    public:
        Security();
        ~Security();
        char * decrypt(char *);
};

#endif
