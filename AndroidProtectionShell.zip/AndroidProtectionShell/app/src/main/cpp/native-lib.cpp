#include <stdio.h>
#include <stdlib.h>
#include<android/log.h>
#include <jni.h> // 先到标准函数库中找文件，找不到再到缺省目录寻找
#include <string>


#include "Security.h"
#define TAG  "emp-jni" // // 这个是自定义的LOG的标识
#define LOGD(...)  __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__) //


extern "C" {


    __attribute ((visibility ("default")))
    JNIEXPORT jint JNI_OnLoad(JavaVM *vm, void *reserved) {
        //这是JNI_OnLoad的声明，必须按照这样的方式声明
        return JNI_VERSION_1_4; //这里很重要，必须返回版本，否则加载会失败。
    }
    __attribute ((visibility ("default")))
    JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
        //   __android_log_print(ANDROID_LOG_ERROR, "tag", "library was unload");
    }

    Security *pSecurity = NULL;
    JNIEXPORT jbyteArray JNICALL Java_com_emp_jni_Security_decrypt(JNIEnv *env, jobject object, jbyteArray data){
        if(pSecurity == NULL){
            pSecurity = new Security;
        }
        jbyte* temp = (jbyte*)env->GetByteArrayElements(data, 0);
        jsize len = env->GetArrayLength(data);
        for(int i=0; i<len; i++){
            *(temp + i) = *(temp + i) ^ 42;
            //LOGD("------data byte: -----%c --- %c ", *(temp + i), dataa[i]);
        }
        //LOGD("------data: -----%s", temp);
        jbyteArray result = env->NewByteArray(len);
        env->SetByteArrayRegion(result, 0, len, temp);
        return result;
    }


    JNIEXPORT void JNICALL Java_com_emp_jni_Security_destroy(JNIEnv *env, jobject object){
        if(pSecurity != NULL){
            pSecurity = NULL;
        }
    }

    JNIEXPORT jint JNICALL Java_com_emp_jni_Security_add(JNIEnv *env, jobject object, jint x, jint y){
        return x + y;
    }

}
