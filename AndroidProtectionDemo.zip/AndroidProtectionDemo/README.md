# AndroidProtectionDemo
Intial commit

Android Studio版， 要被加壳的DEMO程序，对应https://github.com/heqingyong/AndroidShell 中的AndroidProtectionDemo
